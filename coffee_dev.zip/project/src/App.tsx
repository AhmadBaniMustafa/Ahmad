import { Navbar } from './components/Navbar';
import { CoffeeGrid } from './components/CoffeeGrid';
import { UserProfile } from './components/UserProfile';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="space-y-6">
          <UserProfile />
          <CoffeeGrid />
        </div>
      </main>
    </div>
  );
}

export default App;