import { useState } from 'react';
import { User } from '../types/User';
import { useLocalStorage } from '../hooks/useLocalStorage';

export function UserProfile() {
  const [user, setUser] = useLocalStorage<User | null>('user', null);
  const [isEditing, setIsEditing] = useState(false);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    setUser({
      id: user?.id || crypto.randomUUID(),
      name: formData.get('name') as string,
      email: formData.get('email') as string,
      preferences: {
        favoriteRoast: formData.get('favoriteRoast') as string,
        grindType: formData.get('grindType') as string
      }
    });
    setIsEditing(false);
  };

  if (!user || isEditing) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-4">Your Profile</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700">Name</label>
            <input
              type="text"
              id="name"
              name="name"
              defaultValue={user?.name}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
              required
            />
          </div>
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              defaultValue={user?.email}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
              required
            />
          </div>
          <div>
            <label htmlFor="favoriteRoast" className="block text-sm font-medium text-gray-700">Favorite Roast</label>
            <select
              id="favoriteRoast"
              name="favoriteRoast"
              defaultValue={user?.preferences.favoriteRoast}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
            >
              <option value="light">Light</option>
              <option value="medium">Medium</option>
              <option value="dark">Dark</option>
            </select>
          </div>
          <div>
            <label htmlFor="grindType" className="block text-sm font-medium text-gray-700">Preferred Grind</label>
            <select
              id="grindType"
              name="grindType"
              defaultValue={user?.preferences.grindType}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
            >
              <option value="whole">Whole Bean</option>
              <option value="coarse">Coarse</option>
              <option value="medium">Medium</option>
              <option value="fine">Fine</option>
            </select>
          </div>
          <button
            type="submit"
            className="w-full bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 transition-colors"
          >
            Save Profile
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold">Welcome, {user.name}!</h2>
        <button
          onClick={() => setIsEditing(true)}
          className="text-red-600 hover:text-red-700"
        >
          Edit Profile
        </button>
      </div>
      <div className="space-y-2">
        <p className="text-gray-600">Email: {user.email}</p>
        <p className="text-gray-600">Favorite Roast: {user.preferences.favoriteRoast}</p>
        <p className="text-gray-600">Preferred Grind: {user.preferences.grindType}</p>
      </div>
    </div>
  );
}