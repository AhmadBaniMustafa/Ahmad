import { Coffee } from '../types/Coffee';

interface CoffeeCardProps {
  coffee: Coffee;
}

export function CoffeeCard({ coffee }: CoffeeCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden transition-transform hover:scale-105">
      <img 
        src={coffee.image} 
        alt={coffee.name}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h2 className="text-xl font-semibold text-gray-900 mb-2">{coffee.name}</h2>
        <p className="text-gray-600 mb-4">{coffee.description}</p>
        <button className="bg-red-600 text-white px-4 py-2 rounded-full hover:bg-red-700 transition-colors">
          Taste it
        </button>
      </div>
    </div>
  );
}