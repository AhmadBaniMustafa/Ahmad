import { Coffee } from '../types/Coffee';

export const coffees: Coffee[] = [
  {
    id: 1,
    name: "Perspiciatis",
    image: "https://images.unsplash.com/photo-1541167760496-1628856ab772?w=800",
    description: "A rich and bold coffee with hints of chocolate"
  },
  {
    id: 2,
    name: "Voluptatem",
    image: "https://images.unsplash.com/photo-1507133750040-4a8f57021571?w=800",
    description: "Smooth medium roast with caramel notes"
  },
  {
    id: 3,
    name: "Explicabo",
    image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800",
    description: "Light roast with citrus undertones"
  },
  {
    id: 4,
    name: "Architecto",
    image: "https://images.unsplash.com/photo-1501747315-124a0eaca060?w=800",
    description: "Dark roast with intense flavor profile"
  },
  {
    id: 5,
    name: "Beatae",
    image: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=800",
    description: "Balanced blend with nutty finish"
  },
  {
    id: 6,
    name: "Vitae",
    image: "https://images.unsplash.com/photo-1485808191679-5f86510681a2?w=800",
    description: "Ethiopian single origin with floral notes"
  }
];