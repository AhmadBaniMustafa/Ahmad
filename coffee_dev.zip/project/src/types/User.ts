export interface User {
  id: string;
  name: string;
  email: string;
  preferences: {
    favoriteRoast: string;
    grindType: string;
  };
}